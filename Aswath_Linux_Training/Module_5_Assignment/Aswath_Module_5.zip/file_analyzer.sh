#!/bin/bash
#Aswath

LOGFILE="errors.log"

display_help() {
    cat << EOF

Options:
  -d <directory>   Directory to search.
  -k <keyword>     Keyword to search.
  -f <file>        File to search directly.
  --help           Display this help menu.

Examples Usage:
  $0 -d /path/to/dir -k keyword
  $0 -f /path/to/file -k keyword
EOF
}

recursive_search() {
    local directory=$1
    local keyword=$2

    for entry in "$directory"/*; do
        if [ -f "$entry" ]; then
            grep -rw "$keyword" "$entry" && echo "Keyword Found in: $entry" 
            if [ $? -ne 0 ]; then
            	echo "Keyword Not found in: $entry"
             fi
        elif [ -d "$entry" ]; then
            recursive_search "$entry" "$keyword"
        fi
    done
}


log_file_save() {
    echo "[`date`] ERROR: $1" | tee -a "$LOGFILE"
}

#This is the main Script 
while getopts "d:k:f:-:" opt; do
    case $opt in
        d)
            directory="$OPTARG"
            ;;
        k)
            keyword="$OPTARG"
            ;;
        f)
            file="$OPTARG"
            ;;
        -)
            case $OPTARG in
                help)
                    display_help
                    exit 0
                    ;;
                *)
                    log_file_save "Invalid option: --$OPTARG"
                    exit 1
                    ;;
            esac
            ;;
        *)
            log_file_save "Invalid arguments. Use --help for usage."
            exit 1
            ;;
    esac
done


if [ "$#" -eq 0 ]; then
    log_file_save "No arguments provided. Use --help for usage."
    exit 1
fi

if [ -n "$directory" ]; then
    if [ -d "$directory" ]; then
        if [ -n "$keyword" ]; then
            recursive_search "$directory" "$keyword"
        else
            log_file_save "Keyword not provided."
            exit 1
        fi
    else
        log_file_save "Invalid directory: $directory"
        exit 1
    fi
fi

if [ -n "$file" ]; then
    if [ -f "$file" ]; then
        if [ -n "$keyword" ]; then
            grep -w "$keyword" <<< "$(cat "$file")" || echo "Keyword not found in $file"
        else
            log_file_save "Keyword not provided."
            exit 1
        fi
    else
        log_file_save "Invalid file: $file"
        exit 1
    fi
fi


if [[ -z "$directory" ]] && [[ -z "$file" ]]; then
    log_file_save "Neither directory nor file provided. Use --help for usage."
    exit 1
fi


