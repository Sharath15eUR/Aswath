#!/bin/bash
#Aswath S

memory_highest=$(ps aux --sort=-%mem | awk 'NR==2 {print $2,$4,$11}')
pid=$(echo  $memory_highest  | awk '{print $1}')
memory_consumption=$(echo $memory_highest | awk '{print $2}')
process=$(echo $memory_highest | awk '{print $3}')

echo "PID = $pid"
echo "Memory_usage=$memory_consumption%"
echo "Process = $process"

kill -9 $pid
echo "The process $PID is Terminated Succesfully"
