#!/bin/bash
total_size=0
source_dir="$1"
backup_dir="$2"
file_extention="$3"
if [ -d "$source_dir" ]; then
	echo 'Source_Directory exists!!'
else 
	echo 'Create a Source_Directory and add files to it '
fi
if [ -d "$backup_dir" ]; then
	echo 'backup Directory exists!!'
else
	mkdir -p "$backup_dir"
	if [ $? -ne 0 ]; then
		echo "Failed to create backup directory"
		exit 1
	fi
	echo "Backup Directory is created!!"
fi
export BACKUP_COUNT=0
array_list=()
for file in "$source_dir"/*"$file_extention"; do
	if [ -f "$file" ]; then
		array_list+=("$file")
	fi
done


if [ "${#array_list[@]}" -eq 0 ]; then
	echo "No file with '$file_extention' extention exists!"
	exit 0
fi

echo "The Matched files that are going to be backed up are"
echo "-----------------------------------------------------"
for file in "${array_list[@]}"; do
	size=$(stat -c%s "$file")
	echo "$(basename "$file") - Size : $size bytes"
done

for file in "${array_list[@]}"; do
     backup_dir_file="$backup_dir/$(basename "$file")"
	if [ -f "$backup_dir_file" ]; then
		if [ "$file" -nt "$bckup_dir_file" ]; then
			cp "$file" "$backup_dir_file"
			echo "The file is overwritten with newer version $(basename "$file")"
			size=$(stat -c%s "$file")
			total_size=$((total_size + size))
			BACKUP_COUNT=$((BACKUP_COUNT + 1))
		else
			echo "The file present is up to date"
		fi
	else
		cp "$file" "$backup_dir_file"
		size=$(stat -c%s "$file")
		total_size=$((total_size + size))
		BACKUP_COUNT=$((BACKUP_COUNT + 1))
	fi
done

report_file="$backup_dir/backup_report.log"
echo "Backup Report" > "$report_file"
echo "-------------------------------------"
echo "Total files processed: ${#array_list[@]}" >> "$report_file"
echo "Total files Backedup: $BACKUP_COUNT" >> "$report_file"
echo "Total size of file  backed up: $total_size Bytes" >> "$report_file"
echo "Backup Directory: $backup_dir" >> "$report_file"
cat "$report_file"
