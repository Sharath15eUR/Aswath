#!/bin/bash
# Aswath 

input_file="$1"
output_file="$2"

> "$output_file"

frame_time=""
wlan_fc_type=""
wlan_fc_subtype=""


while IFS= read -r line; do

    temp_frame_time=$(echo "$line" | grep -oP '(?<=frame.time": ")[^"]+')
    temp_wlan_fc_type=$(echo "$line" | grep -oP '(?<=wlan.fc.type": ")[^"]+')
    temp_wlan_fc_subtype=$(echo "$line" | grep -oP '(?<=wlan.fc.subtype": ")[^"]+')

    if [[ -n "$temp_frame_time" ]]; then
        if [[ -n "$frame_time" && -n "$wlan_fc_type" && -n "$wlan_fc_subtype" ]]; then
            echo "\"frame.time\": \"$frame_time\"," >> "$output_file"
            echo "\"wlan.fc.type\": \"$wlan_fc_type\"," >> "$output_file"
            echo "\"wlan.fc.subtype\": \"$wlan_fc_subtype\"" >> "$output_file"
            
        fi

        frame_time="$temp_frame_time"
    fi

    if [[ -n "$temp_wlan_fc_type" ]]; then
        wlan_fc_type="$temp_wlan_fc_type"
    fi
    if [[ -n "$temp_wlan_fc_subtype" ]]; then
        wlan_fc_subtype="$temp_wlan_fc_subtype"
    fi
done < "$input_file"

if [[ -n "$frame_time" && -n "$wlan_fc_type" && -n "$wlan_fc_subtype" ]]; then
    echo "\"frame.time\": \"$frame_time\"," >> "$output_file"
    echo "\"wlan.fc.type\": \"$wlan_fc_type\"," >> "$output_file"
    echo "\"wlan.fc.subtype\": \"$wlan_fc_subtype\"" >> "$output_file"
fi

echo "Extracting process completed. Extracted data is saved in $output_file"
